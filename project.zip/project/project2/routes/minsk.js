
const express = require('express');
const router = express.Router();
const faker = require('faker');

/* GET home page. */
/*router.get('/', (req, res) => {
  res.render('index', { title: 'Express' });
});
*/
module.exports = router;

router.get('/museums', (req, res) => {
    var museums = [         
	    { 
	    	"name": "Музей Декларуа",
	    },
	    { 
	    	"name": "Музей Франкештейна"
	    }
    ]; 
 
 
res.render('minsk',{"museums": museums});
 });




